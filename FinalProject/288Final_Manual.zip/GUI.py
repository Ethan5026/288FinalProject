import pygame, sys, socket, threading
import numpy as np
import time

HOST = "192.168.1.1"
PORT = 288

WIDTH = 1000
HEIGHT = 750

DIST_SCALE = 8
SCAN_LENGTH = 60 * DIST_SCALE
CYBOT_RADIUS = 40
HOLD_TIME = 10

class Point:
   def __init__(self, x, y, color, rad, hold_time) -> None:
      self.x = x
      self.y = y
      self.color = color
      self.rad = rad
      self.time = time.time()
      self.hold_time = hold_time

class GUI:
   def __init__(self) -> None:
      self.cybot_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      print("Connecting...")
      self.cybot_socket.connect((HOST, PORT))
      print("Connected")
      self.cybot_file = self.cybot_socket.makefile("rbw", buffering=0)

      self.scan_angle = 0
      self.scan_points: list[Point] = []
      self.recieve_thread = threading.Thread(target=self.reciever)
      self.recieve_thread.daemon = True
      self.recieve_thread.start()

      pygame.init()
      self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
      pygame.display.set_caption("Cybot")
      last_char = "\0".encode()
      while True:
         char = last_char
         for event in pygame.event.get():
            if event.type == pygame.QUIT:
               self.cybot_socket.send('!'.encode())
               pygame.quit()
               sys.exit()
            elif event.type == pygame.KEYDOWN:
               if event.key == pygame.K_UP: char = "w".encode()
               elif event.key == pygame.K_DOWN: char = "s".encode()
               elif event.key == pygame.K_LEFT: char = "a".encode()
               elif event.key == pygame.K_RIGHT: char = "d".encode()
               elif event.key == pygame.K_p: self.cybot_socket.send("p".encode())
               elif event.key == pygame.K_c: self.cybot_socket.send("c".encode())
               elif event.key == pygame.K_q: 
                  self.cybot_socket.send('q'.encode())
                  pygame.quit()
                  sys.exit()

         keys=pygame.key.get_pressed()
         if not (keys[pygame.K_UP] or keys[pygame.K_DOWN] or keys[pygame.K_LEFT] or keys[pygame.K_RIGHT]):
            char = "!".encode()

         if char != last_char:
            last_char = char
            self.cybot_socket.send(char)

         self.screen.fill((0,0,0))
         pygame.draw.circle(self.screen, (155,155,155), (WIDTH / 2, HEIGHT / 2), CYBOT_RADIUS)
         pygame.draw.line(self.screen, (0, 255, 0), (WIDTH / 2, HEIGHT / 2 - CYBOT_RADIUS * 4/5), (SCAN_LENGTH * np.cos(self.scan_angle * np.pi / 180) + WIDTH / 2, -SCAN_LENGTH * np.sin(self.scan_angle * np.pi / 180) + HEIGHT / 2  - CYBOT_RADIUS * 4/5),  1)
         for i in self.scan_points:
            if time.time() - i.time > i.hold_time:
               self.scan_points.remove(i)
            pygame.draw.circle(self.screen, i.color, (i.x + WIDTH / 2, -i.y + HEIGHT / 2 - CYBOT_RADIUS * 4/5), i.rad)

         pygame.display.update()

   def reciever(self):
      while True:
         try:
            lines = [x.strip() for x in self.cybot_file.readline().decode().strip().split('\n')]
            for line in lines:
               uuid = line[0]
               line = line[1:]
               if (uuid == 'p'):
                  self.scan_angle = int(line.split(",")[0])
                  dist = float(line.split(",")[1].strip()) * DIST_SCALE
                  if (dist < SCAN_LENGTH):
                     self.scan_points += [Point(
                        dist * np.cos(self.scan_angle * np.pi / 180), 
                        dist * np.sin(self.scan_angle * np.pi / 180),
                        (255, 0, 0),
                        2,
                        10
                     )]

               elif (uuid == 'i'):
                  forward = float(line.split(",")[0])
                  rotate = float(line.split(",")[1])
                  bumpLeft = int(line.split(",")[2]) == 1
                  bumpRight = int(line.split(",")[3]) == 1
                  cliff = int(line.split(",")[4])

                  if bumpLeft:
                     self.scan_points += [Point(
                        -CYBOT_RADIUS * 4/5, 
                        CYBOT_RADIUS / DIST_SCALE * 4/5,
                        (0, 0, 255),
                        10,
                        20
                     )]
                  if bumpRight:
                     self.scan_points += [Point(
                        CYBOT_RADIUS * 4/5, 
                        CYBOT_RADIUS / DIST_SCALE * 4/5,
                        (0, 0, 255),
                        10,
                        20
                     )]
                  if cliff > 8500:
                     self.scan_points += [Point(
                        0, 
                        CYBOT_RADIUS / DIST_SCALE,
                        (255, 255, 255),
                        10,
                        20
                     )]
                  if cliff < 6500:
                     self.scan_points += [Point(
                        0, 
                        CYBOT_RADIUS / DIST_SCALE,
                        (255, 140, 0),
                        10,
                        20
                     )]

                  for i in self.scan_points:
                     i.y -= forward
                     dist = np.sqrt(i.x * i.x + i.y * i.y)
                     angle = np.arctan2(i.y, i.x)
                     i.x = dist * np.cos(angle - rotate * np.pi / 180)
                     i.y = dist * np.sin(angle - rotate * np.pi / 180)

               elif  (uuid == 'c'):
                  print(line)


         except Exception as e:
            print("ERROR: " + str(e))

if __name__ == "__main__":
   GUI()