#include "Timer.h"
#include "uart.h"
#include "ping.h"
#include "IR.h"
#include "lcd.h"
#include "entertainer.h"
#include "button.h"
#include "pwm.h"
#include "open_interface.h"
#include "userDisplay.h"

#define MAX_ANGLE 180
#define MIN_ANGLE 0
#define SCAN_DELAY 3
#define DRIVE_SPEED 100
#define TURN_SPEED 200

typedef struct scan_struct{
    double sound_dist;
    int IR_raw_val;
} Scan_t;

void capture(Scan_t *scanData);

/**
 * main.c
 */
int main(void)
{
    timer_init();
    uart_init();
    uart_handlerInit();
    ping_init();
    IR_init();
    lcd_init();
    pwm_init();
    entertainer_init();
    userDisplay_init();

    lcd_printf("Press the CLEAN\nbutton on the rumba");
    oi_t oi;
    oi_init(&oi);
    lcd_clear();

    int sensor_angle = (MIN_ANGLE + MAX_ANGLE) / 2;
    int sensor_direction = 1;
    double scan_ir;
    char message[100];
    oi_setWheels(0, 0);
    int hazard_found = 0;
    while (1) {
        if (sensor_angle == MIN_ANGLE || MAX_ANGLE == sensor_angle) {
            sensor_direction *= -1;
        }
        sensor_angle += sensor_direction;
        pwm_setAngle(sensor_angle);
        scan_ir = IR_receiveCm();
        timer_waitMillis(SCAN_DELAY);

        sprintf(message, "p%d,%lf\n", sensor_angle, scan_ir);
        uart_sendStr(message);

        if (uart_flag) {
            switch (uart_data) {
            case 'w':
                oi_setWheels(DRIVE_SPEED, DRIVE_SPEED);
                break;
            case 's':
                oi_setWheels(-DRIVE_SPEED, -DRIVE_SPEED);
                break;
            case 'a':
                oi_setWheels(DRIVE_SPEED, -DRIVE_SPEED);
                break;
            case 'd':
                oi_setWheels(-DRIVE_SPEED, DRIVE_SPEED);
                break;
            case '!':
                oi_setWheels(0, 0);
                break;
            case 'p':
                entertainer_play();
                break;
            case 'c':
                userDisplay_sell();
                break;
            case 'q':
                oi_free(&oi);
                return 0;
            default:
                oi_setWheels(0, 0);
                break;
            }
            uart_flag = 0;
        }

        if (sensor_angle % 20 == 0) {
            oi_short_update(&oi);
            uint16_t cliff = oi.cliffLeftSignal + oi.cliffFrontLeftSignal + oi.cliffFrontRightSignal + oi.cliffRightSignal;
            sprintf(message, "i%lf,%lf,%d,%d, %d\n", oi.distance, oi.angle, oi.bumpLeft, oi.bumpRight, cliff);
            if (cliff > 8500 || cliff < 6000 || oi.bumpLeft || oi.bumpRight) {
                if (!hazard_found) {oi_setWheels(0, 0);}
                hazard_found = 1;
            } else {
                hazard_found = 0;
            }
            uart_sendStr(message);
        }


    }
}

void capture(Scan_t *scanData){
    scanData->IR_raw_val = IR_receiveCm();
    //scanData->sound_dist = ping_receive();
}
